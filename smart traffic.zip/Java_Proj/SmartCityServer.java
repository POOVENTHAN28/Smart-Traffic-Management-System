import com.google.gson.Gson;
import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;
import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.*;

// Main Server Class
public class SmartCityServer {
    private static final int PORT = 8080;
    private static final Gson gson = new Gson();
    private static final TransportationSystem transportSystem = new TransportationSystem();
    
    public static void main(String[] args) {
        try {
            HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);
            
            // API endpoints
            server.createContext("/", SmartCityServer::handleRoot);
            server.createContext("/api/vehicles", SmartCityServer::handleVehicles);
            server.createContext("/api/traffic", SmartCityServer::handleTraffic);
            server.createContext("/api/routes", SmartCityServer::handleRoutes);
            server.createContext("/api/alerts", SmartCityServer::handleAlerts);
            server.createContext("/api/statistics", SmartCityServer::handleStatistics);
            
            server.setExecutor(Executors.newFixedThreadPool(10));
            server.start();
            
            // Start simulation
            transportSystem.startSimulation();
            
            System.out.println("==================================");
            System.out.println("Smart City Server Started!");
            System.out.println("Access at: http://localhost:" + PORT);
            System.out.println("==================================");
        } catch (IOException e) {
            System.err.println("Failed to start server: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private static void handleRoot(HttpExchange exchange) throws IOException {
        setCorsHeaders(exchange);
        
        // Try to serve index.html file
        try {
            Path indexPath = Paths.get("index.html");
            if (Files.exists(indexPath)) {
                byte[] bytes = Files.readAllBytes(indexPath);
                exchange.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
                exchange.sendResponseHeaders(200, bytes.length);
                OutputStream os = exchange.getResponseBody();
                os.write(bytes);
                os.close();
                return;
            }
        } catch (IOException e) {
            System.err.println("Could not read index.html: " + e.getMessage());
        }
        
        // Fallback message if index.html not found
        String response = getHTMLContent();
        exchange.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
        byte[] bytes = response.getBytes(StandardCharsets.UTF_8);
        exchange.sendResponseHeaders(200, bytes.length);
        OutputStream os = exchange.getResponseBody();
        os.write(bytes);
        os.close();
    }
    
    private static void handleVehicles(HttpExchange exchange) throws IOException {
        setCorsHeaders(exchange);
        if ("OPTIONS".equals(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(204, -1);
            return;
        }
        
        try {
            List<Vehicle> vehicles = transportSystem.getAllVehicles();
            String json = gson.toJson(vehicles);
            sendJsonResponse(exchange, json, 200);
        } catch (Exception e) {
            sendJsonResponse(exchange, "{\"error\": \"" + e.getMessage() + "\"}", 500);
        }
    }
    
    private static void handleTraffic(HttpExchange exchange) throws IOException {
        setCorsHeaders(exchange);
        if ("OPTIONS".equals(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(204, -1);
            return;
        }
        
        try {
            List<TrafficData> traffic = transportSystem.getTrafficData();
            String json = gson.toJson(traffic);
            sendJsonResponse(exchange, json, 200);
        } catch (Exception e) {
            sendJsonResponse(exchange, "{\"error\": \"" + e.getMessage() + "\"}", 500);
        }
    }
    
    private static void handleRoutes(HttpExchange exchange) throws IOException {
        setCorsHeaders(exchange);
        if ("OPTIONS".equals(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(204, -1);
            return;
        }
        
        try {
            List<BusRoute> routes = transportSystem.getBusRoutes();
            String json = gson.toJson(routes);
            sendJsonResponse(exchange, json, 200);
        } catch (Exception e) {
            sendJsonResponse(exchange, "{\"error\": \"" + e.getMessage() + "\"}", 500);
        }
    }
    
    private static void handleAlerts(HttpExchange exchange) throws IOException {
        setCorsHeaders(exchange);
        if ("OPTIONS".equals(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(204, -1);
            return;
        }
        
        try {
            List<Alert> alerts = transportSystem.getAlerts();
            String json = gson.toJson(alerts);
            sendJsonResponse(exchange, json, 200);
        } catch (Exception e) {
            sendJsonResponse(exchange, "{\"error\": \"" + e.getMessage() + "\"}", 500);
        }
    }
    
    private static void handleStatistics(HttpExchange exchange) throws IOException {
        setCorsHeaders(exchange);
        if ("OPTIONS".equals(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(204, -1);
            return;
        }
        
        try {
            Map<String, Object> stats = transportSystem.getStatistics();
            String json = gson.toJson(stats);
            sendJsonResponse(exchange, json, 200);
        } catch (Exception e) {
            sendJsonResponse(exchange, "{\"error\": \"" + e.getMessage() + "\"}", 500);
        }
    }
    
    private static void setCorsHeaders(HttpExchange exchange) {
        exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        exchange.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");
    }
    
    private static void sendJsonResponse(HttpExchange exchange, String json, int statusCode) throws IOException {
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        exchange.sendResponseHeaders(statusCode, bytes.length);
        OutputStream os = exchange.getResponseBody();
        os.write(bytes);
        os.close();
    }
    
    private static String getHTMLContent() {
        return "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Smart City Monitor</title></head>" +
               "<body><h1>Smart City Transportation Monitoring System</h1>" +
               "<p>Please use the HTML file provided separately or access the API endpoints:</p>" +
               "<ul><li>/api/vehicles</li><li>/api/traffic</li><li>/api/routes</li>" +
               "<li>/api/alerts</li><li>/api/statistics</li></ul></body></html>";
    }
}

// Transportation System
class TransportationSystem {
    private final List<Vehicle> vehicles = new CopyOnWriteArrayList<>();
    private final List<TrafficData> trafficData = new CopyOnWriteArrayList<>();
    private final List<BusRoute> busRoutes = new CopyOnWriteArrayList<>();
    private final List<Alert> alerts = new CopyOnWriteArrayList<>();
    private final Random random = new Random();
    private ScheduledExecutorService scheduler;
    
    public TransportationSystem() {
        initializeSystem();
    }
    
    private void initializeSystem() {
        // Initialize bus routes with realistic stops
        busRoutes.add(new BusRoute("R1", "Downtown Express", "Active",
            Arrays.asList(
                new Location(40.7128, -74.0060, "City Hall"),
                new Location(40.7489, -73.9680, "Grand Central"),
                new Location(40.7580, -73.9855, "Times Square"),
                new Location(40.7614, -73.9776, "Central Park South")
            )));
        
        busRoutes.add(new BusRoute("R2", "Airport Shuttle", "Active",
            Arrays.asList(
                new Location(40.7128, -74.0060, "Downtown Terminal"),
                new Location(40.6782, -73.9442, "Brooklyn Hub"),
                new Location(40.6413, -73.7781, "JFK Airport"),
                new Location(40.6895, -73.8239, "Jamaica Station")
            )));
        
        busRoutes.add(new BusRoute("R3", "Uptown Local", "Active",
            Arrays.asList(
                new Location(40.7128, -74.0060, "Financial District"),
                new Location(40.7282, -73.9942, "Union Square"),
                new Location(40.7794, -73.9632, "Upper East Side")
            )));
        
        // Initialize vehicles with realistic data
        String[] busIds = {"BUS-101", "BUS-102", "BUS-103", "BUS-104", "BUS-105"};
        String[] taxiIds = {"TAXI-201", "TAXI-202", "TAXI-203", "TAXI-204", "TAXI-205"};
        String[] emergencyIds = {"EMG-301", "EMG-302", "EMG-303", "EMG-304", "EMG-305"};
        
        for (String id : busIds) {
            vehicles.add(new Vehicle(id, "bus", 
                40.7128 + (random.nextDouble() - 0.5) * 0.1,
                -74.0060 + (random.nextDouble() - 0.5) * 0.1,
                20 + random.nextInt(30), "R" + (random.nextInt(3) + 1), 75 + random.nextInt(26)));
        }
        
        for (String id : taxiIds) {
            vehicles.add(new Vehicle(id, "taxi",
                40.7128 + (random.nextDouble() - 0.5) * 0.1,
                -74.0060 + (random.nextDouble() - 0.5) * 0.1,
                15 + random.nextInt(35), null, 0));
        }
        
        for (String id : emergencyIds) {
            vehicles.add(new Vehicle(id, "emergency",
                40.7128 + (random.nextDouble() - 0.5) * 0.1,
                -74.0060 + (random.nextDouble() - 0.5) * 0.1,
                40 + random.nextInt(41), null, 0));
        }
        
        // Initialize traffic data
        String[] locations = {"5th Avenue & 42nd St", "Broadway & Times Square", "Park Ave & 59th St", 
                             "Madison Ave & 34th St", "Lexington Ave & 53rd St", "FDR Drive North",
                             "West Side Highway", "Brooklyn Bridge"};
        for (String loc : locations) {
            trafficData.add(new TrafficData(loc, 
                40.7128 + (random.nextDouble() - 0.5) * 0.1,
                -74.0060 + (random.nextDouble() - 0.5) * 0.1,
                "moderate", random.nextInt(100), 25 + random.nextInt(40)));
        }
    }
    
    public void startSimulation() {
        scheduler = Executors.newScheduledThreadPool(1);
        scheduler.scheduleAtFixedRate(() -> {
            try {
                updateVehicles();
                updateTraffic();
                generateAlerts();
            } catch (Exception e) {
                System.err.println("Simulation error: " + e.getMessage());
            }
        }, 0, 3, TimeUnit.SECONDS);
    }
    
    private void updateVehicles() {
        for (Vehicle v : vehicles) {
            // Smooth movement with boundaries
            double latChange = (random.nextDouble() - 0.5) * 0.0008;
            double lngChange = (random.nextDouble() - 0.5) * 0.0008;
            
            v.lat = Math.max(40.65, Math.min(40.85, v.lat + latChange));
            v.lng = Math.max(-74.05, Math.min(-73.90, v.lng + lngChange));
            
            // Update speed based on vehicle type
            if ("emergency".equals(v.type)) {
                v.speed = 40 + random.nextInt(41);
            } else if ("bus".equals(v.type)) {
                v.speed = 15 + random.nextInt(30);
                v.capacity = 75 + random.nextInt(26);
            } else {
                v.speed = 10 + random.nextInt(40);
            }
        }
    }
    
    private void updateTraffic() {
        for (TrafficData td : trafficData) {
            // Gradual traffic changes
            int change = random.nextInt(21) - 10;
            td.density = Math.max(0, Math.min(100, td.density + change));
            
            if (td.density < 30) td.status = "light";
            else if (td.density < 70) td.status = "moderate";
            else td.status = "heavy";
            
            td.avgSpeed = Math.max(5, Math.min(65, 65 - (td.density * 0.6)));
        }
    }
    
    private void generateAlerts() {
        alerts.clear();
        
        // Generate random alerts (30% chance)
        if (random.nextDouble() > 0.7) {
            String[] types = {"accident", "congestion", "construction", "weather", "event"};
            String[][] messages = {
                {"Multi-vehicle accident on 5th Avenue", "Accident reported near Times Square", "Vehicle collision on FDR Drive"},
                {"Heavy congestion on Broadway", "Traffic jam at Lincoln Tunnel", "Severe delays on Brooklyn Bridge"},
                {"Road construction on Park Avenue", "Lane closure on West Side Highway", "Roadwork ahead on Madison Ave"},
                {"Poor visibility due to fog", "Heavy rain affecting traffic", "Icy conditions reported"},
                {"Concert at Madison Square Garden", "Marathon affecting downtown routes", "Parade on 5th Avenue"}
            };
            
            int typeIdx = random.nextInt(types.length);
            int msgIdx = random.nextInt(messages[typeIdx].length);
            
            alerts.add(new Alert(types[typeIdx], messages[typeIdx][msgIdx], 
                40.7128 + (random.nextDouble() - 0.5) * 0.1,
                -74.0060 + (random.nextDouble() - 0.5) * 0.1,
                getAlertSeverity(types[typeIdx])));
        }
    }
    
    private String getAlertSeverity(String type) {
        if ("accident".equals(type) || "weather".equals(type)) return "high";
        if ("congestion".equals(type)) return "medium";
        return "low";
    }
    
    public List<Vehicle> getAllVehicles() { 
        return new ArrayList<>(vehicles); 
    }
    
    public List<TrafficData> getTrafficData() { 
        return new ArrayList<>(trafficData); 
    }
    
    public List<BusRoute> getBusRoutes() { 
        return new ArrayList<>(busRoutes); 
    }
    
    public List<Alert> getAlerts() { 
        return new ArrayList<>(alerts); 
    }
    
    public Map<String, Object> getStatistics() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalVehicles", vehicles.size());
        stats.put("activeBuses", vehicles.stream().filter(v -> "bus".equals(v.type)).count());
        stats.put("activeTaxis", vehicles.stream().filter(v -> "taxi".equals(v.type)).count());
        stats.put("emergencyVehicles", vehicles.stream().filter(v -> "emergency".equals(v.type)).count());
        stats.put("activeAlerts", alerts.size());
        stats.put("avgSpeed", vehicles.stream().mapToInt(v -> v.speed).average().orElse(0));
        stats.put("heavyTrafficAreas", trafficData.stream().filter(t -> "heavy".equals(t.status)).count());
        return stats;
    }
}

// Data Models
class Vehicle {
    String id;
    String type;
    double lat;
    double lng;
    int speed;
    String route;
    int capacity;
    
    Vehicle(String id, String type, double lat, double lng, int speed, String route, int capacity) {
        this.id = id;
        this.type = type;
        this.lat = lat;
        this.lng = lng;
        this.speed = speed;
        this.route = route;
        this.capacity = capacity;
    }
}

class TrafficData {
    String location;
    double lat;
    double lng;
    String status;
    int density;
    double avgSpeed;
    
    TrafficData(String location, double lat, double lng, String status, int density, double avgSpeed) {
        this.location = location;
        this.lat = lat;
        this.lng = lng;
        this.status = status;
        this.density = density;
        this.avgSpeed = avgSpeed;
    }
}

class BusRoute {
    String id;
    String name;
    String status;
    List<Location> stops;
    
    BusRoute(String id, String name, String status, List<Location> stops) {
        this.id = id;
        this.name = name;
        this.status = status;
        this.stops = stops;
    }
}

class Location {
    double lat;
    double lng;
    String name;
    
    Location(double lat, double lng, String name) {
        this.lat = lat;
        this.lng = lng;
        this.name = name;
    }
}

class Alert {
    String type;
    String message;
    double lat;
    double lng;
    long timestamp;
    String severity;
    
    Alert(String type, String message, double lat, double lng, String severity) {
        this.type = type;
        this.message = message;
        this.lat = lat;
        this.lng = lng;
        this.severity = severity;
        this.timestamp = System.currentTimeMillis();
    }
}